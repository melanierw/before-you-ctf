<?php
$FLAG = "{{flag}}";
$database_file = "../users.db";
?>